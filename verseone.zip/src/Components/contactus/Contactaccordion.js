import Accordion from 'react-bootstrap/Accordion';
import "./Contact.css";

function BasicExample() {
  return (<>
    <Accordion >
      <Accordion.Item eventKey="0" style={{borderBottom:"1px solid #CACACA"}}>
        <Accordion.Header className="Accordion-Header">You believe that you may be owed royalties from Verse One Distribution, you want to know who to contact for assistance?</Accordion.Header>
        <Accordion.Body className='pb-5 mb-5'>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1"  style={{borderBottom:"1px solid #CACACA"}}>
        <Accordion.Header className="Accordion-Header">You found your music being distributed or sold illegally on another web site or service and you want to report this?</Accordion.Header>
        <Accordion.Body>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header className="Accordion-Header">If you are a journalist or press member and you want to contact someone in our communications department?</Accordion.Header>
        <Accordion.Body>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>
    <div className='d-flex justify-content-center my-5' >
        <button className='btn contatc_button' style={{fontSize:"20px"}}>Report a copyright dispute</button>
    </div>
    </> );
}

export default BasicExample;