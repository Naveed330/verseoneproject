import snap from "../assets/nwes-snap.png"
export const data=[
    {
        imgae:snap,
        text:"New musical festival start now!!!",
        paragraph:"As a result of musical works being spread worldwide like mustard seeds, it’s important to know where the seed fell, whether is germinated or died and why it died.",
        date:"19/08/2022",
        name:"by Thaïs Parvez",
        btn:"Read now"
    },
    {
        imgae:snap,
        text:"New musical festival start now!!!",
        paragraph:"As a result of musical works being spread worldwide like mustard seeds, it’s important to know where the seed fell, whether is germinated or died and why it died.",
        date:"19/08/2022",
        name:"by Thaïs Parvez",
        btn:"Read now"
    }

];
export const Images=[
    {
        imgae:snap,
        text:"New musical festival start now!!!",
        paragraph:"As a result of musical works being spread worldwide like mustard seeds, it’s important to know where the seed fell, whether is germinated or died and why it died.",
        date:"19/08/2022",
        name:"by Thaïs Parvez",
        btn:"Read now"
    },
    {
        imgae:snap,
        text:"New musical festival start now!!!",
        paragraph:"As a result of musical works being spread worldwide like mustard seeds, it’s important to know where the seed fell, whether is germinated or died and why it died.",
        date:"19/08/2022",
        name:"by Thaïs Parvez",
        btn:"Read now"
    },
    {
        imgae:snap,
        text:"New musical festival start now!!!",
        paragraph:"As a result of musical works being spread worldwide like mustard seeds, it’s important to know where the seed fell, whether is germinated or died and why it died.",
        date:"19/08/2022",
        name:"by Thaïs Parvez",
        btn:"Read now"
    },
    {
        imgae:snap,
        text:"New musical festival start now!!!",
        paragraph:"As a result of musical works being spread worldwide like mustard seeds, it’s important to know where the seed fell, whether is germinated or died and why it died.",
        date:"19/08/2022",
        name:"by Thaïs Parvez",
        btn:"Read now"
    },
    {
        imgae:snap,
        text:"New musical festival start now!!!",
        paragraph:"As a result of musical works being spread worldwide like mustard seeds, it’s important to know where the seed fell, whether is germinated or died and why it died.",
        date:"19/08/2022",
        name:"by Thaïs Parvez",
        btn:"Read now"
    },
    {
        imgae:snap,
        text:"New musical festival start now!!!",
        paragraph:"As a result of musical works being spread worldwide like mustard seeds, it’s important to know where the seed fell, whether is germinated or died and why it died.",
        date:"19/08/2022",
        name:"by Thaïs Parvez",
        btn:"Read now"
    }
  
]
