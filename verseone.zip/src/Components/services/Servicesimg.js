import tidal from "../assets/tidal.png";
import deezer from "../assets/deezer.png";
import spo from "../assets/spo.png";
import utube from "../assets/utube.png";
export const servicedata = [
  {
    id: 0,
    imageurl: tidal,
  },
  {
    id: 0,
    imageurl: deezer,
  },
  {
    id: 0,
    imageurl: spo,
  },
  {
    id: 0,
    imageurl: utube,
  },
  
];
