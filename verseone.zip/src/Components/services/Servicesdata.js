import one from "../assets/one.png";
import three from "../assets/three.png";
import four from "../assets/four.png";
import two from "../assets/two.png";
export const Data = [
  {
    id: 0,
    imageurl: one,
  },
  {
    id: 0,
    imageurl: two,
  },
  {
    id: 0,
    imageurl: three,
  },
  {
    id: 0,
    imageurl: four,
  },
  
];
