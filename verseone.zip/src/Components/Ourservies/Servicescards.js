import record from "../assets/record.png";
import trend from "../assets/trend.png";
import aa from "../assets/aa.png";
// import record from "../assets/record.png"
export const data = [
  {
    id: 0,
    imagepath: record,
    title: "Music Distribution",
  },
  {
    id: 0,
    imagepath: trend,
    title: "Analytics",
  },
  {
    id: 0,
    imagepath: aa,
    title: "Publishing",
  },
  {
    id: 0,
    imagepath: aa,
    title: "Go Asia",
  },
];
