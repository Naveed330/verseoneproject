import aimage from "../assets/a1.png";
import bimage from "../assets/a2.png"
import cimage from "../assets/a3.png"
import dimage from "../assets/a4.png"
import eimage from "../assets/a5.png"
import fimage from "../assets/a6.png"
export const DSPdata = [
  {
    id: 0,
    imageurl: aimage,
    des: "Lacus, gravida nibh cras senectus egestas tempus purus. Sed velit ultrices faucibus sed risus. ",
  },
  {
    id: 1,
    imageurl: bimage,
    des: "Lacus, gravida nibh cras senectus egestas tempus purus. Sed velit ultrices faucibus sed risus. ",
  },
  {
    id: 2,
    imageurl: cimage,
    des: "Lacus, gravida nibh cras senectus egestas tempus purus. Sed velit ultrices faucibus sed risus. ",
  },
  {
    id: 3,
    imageurl: dimage,
    des: "Lacus, gravida nibh cras senectus egestas tempus purus. Sed velit ultrices faucibus sed risus. ",
  },
  {
    id: 4,
    imageurl: eimage,
    des: "Lacus, gravida nibh cras senectus egestas tempus purus. Sed velit ultrices faucibus sed risus. ",
  },
  {
    id: 5,
    imageurl: fimage,
    des: "Lacus, gravida nibh cras senectus egestas tempus purus. Sed velit ultrices faucibus sed risus. ",
  },
];
